package com.keleniya;

/**
 *
 * @author Kangasuthan
 */
public class Van extends Vehicle{

    private double cargoVolume;

    public Van(String plateID,
               String brandName,
               DateTime entryTime,
               double cargoVolume) {
        super(plateID, brandName, entryTime);
        this.cargoVolume = cargoVolume;
    }

    public double getCargoVolume() {
        return cargoVolume;
    }

    public void setCargoVolume(double cargoVolume) {
        this.cargoVolume = cargoVolume;
    }
}
