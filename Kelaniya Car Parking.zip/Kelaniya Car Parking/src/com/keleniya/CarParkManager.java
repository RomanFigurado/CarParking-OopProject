package com.keleniya;

public interface CarParkManager {

      void addVehicle();// public abstract method  held  by interface

      void deleteVehicle();// public abstract method held  by interface

      void displayCurrentList();// public abstract method held  by interface

     void printStatistics();

      void displayPerDayList();

      void displayParkingCharges();
}
