package com.keleniya;

/**
 *
 * @author Kanga
 *
 */
public class Car extends Vehicle {
    private int noOfDoors;

    public Car(String id, String brand, DateTime entryTime, int noOfDoors) {
        super(id, brand, entryTime);
        this.noOfDoors = noOfDoors;
    }

    public int getNoOfDoors() {
        return noOfDoors;
    }

    public void setNoOfDoors(int noOfDoors) {
        this.noOfDoors = noOfDoors;
    }
}
