package com.keleniya;

/**
 * Explain about this class and it's methods
 *
 * @author Roman
 */
public class MotorBike extends Vehicle{

    protected int bikeEngineSize;

    public MotorBike(String plateID,
                     String brandName,
                     DateTime entryTime,
                     int bikeEngineSize) {
        super(plateID, brandName, entryTime);
        this.bikeEngineSize = bikeEngineSize;
    }

    public int getBikeEngineSize() {
        return bikeEngineSize;
    }

    public void setBikeEngineSize(int bikeEngineSize) {
        this.bikeEngineSize = bikeEngineSize;
    }
}
