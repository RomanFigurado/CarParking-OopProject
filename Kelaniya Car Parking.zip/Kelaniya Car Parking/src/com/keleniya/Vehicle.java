package com.keleniya;

/**
 * Explain about this class and it's methods
 *
 * @author Roman
 */
public abstract class Vehicle {
    protected String plateID;
    protected String brandName;
    protected DateTime entryTime;

    protected Vehicle(String plateID,
                   String brandName,
                   DateTime entryTime) {
        this.plateID = plateID;
        this.brandName = brandName;
        this.entryTime = entryTime;
    }

    public String getPlateID() {
        return plateID;
    }

    public void setPlateID(String plateID) {
        this.plateID = plateID;
    }

    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    public String getEntryTime() {
        return entryTime.getHours() + " : " + entryTime.getMinutes() + " " + entryTime.getDay() + " / " + entryTime.getMonth()
                + " / " + entryTime.getYear();
    }

    public void setEntryTime(DateTime entryTime) {
        this.entryTime = entryTime;
    }

    /**
     * Describe about this method
     * @return what is going to be return
     */
    public DateTime getEntryTimeObject() {
        return entryTime;
    }
}
